# EquaTube DSP — starter project

Proyek starter Android dengan Kotlin + Jetpack Compose + C++17 + Google Oboe.

## Buka di Android Studio
1. Ekstrak ZIP, lalu pilih **Open** dan arahkan ke folder `EquaTubeDSP`.
2. Install Android SDK Platform 36, NDK (Side by side), CMake 3.22.1, dan JDK 17 dari SDK Manager.
3. Sinkronkan Gradle. Pada konfigurasi CMake pertama, koneksi internet diperlukan agar FetchContent mengunduh Oboe `1.9.3`.
4. Jalankan pada perangkat Android fisik. Berikan izin mikrofon, lalu tekan START.

## Struktur utama
- `app/src/main/java/com/example/equatubedsp/MainActivity.kt` — UI Compose dan JNI declarations.
- `app/src/main/cpp/AudioEngine.h/.cpp` — stream Oboe, ring buffer SPSC, DSP.
- `app/src/main/cpp/native-lib.cpp` — JNI.
- `app/src/main/cpp/CMakeLists.txt` — FetchContent Oboe dan native build.
- `app/build.gradle.kts` — Android/Compose/NDK configuration.

## Catatan implementasi dan batasan
- Input dan output dibuka sebagai Float PCM stereo, LowLatency, dan meminta Exclusive. Jika Exclusive ditolak oleh perangkat/driver, kode mencoba Shared.
- Input callback menulis ke ring buffer SPSC; output callback membaca dan memprosesnya. Callback tidak memakai mutex, alokasi heap, logging, atau operasi I/O.
- Parameter slider disimpan sebagai atomik. UI mengirim perubahan melalui JNI; audio callback membaca snapshot atomik.
- DSP saat ini berisi crossover lima band sederhana (SUB/LOW/MID/HIGH/AIR), compressor soft-knee dasar (threshold tetap -12 dB), dan gain output. Ini fondasi/rujukan, bukan mastering-grade DSP.
- Spectrum monitor saat ini hanya visual placeholder, bukan analyzer dari sampel audio.
- RATIO/KNEE/ATTACK/RELEASE mengendalikan compressor sederhana. GAIN berupa pengali linear 0–2.5×.
- Routing input USB/soundcard bergantung pada dukungan Android, driver, izin, dan pemilihan perangkat oleh sistem. Starter ini memakai default input/output route; belum menyediakan pemilih perangkat USB.
- Latensi round-trip tidak dapat dijamin. Ukur pada perangkat target; exclusive/low-latency adalah permintaan, bukan jaminan.
- Untuk live PA, uji dengan volume rendah terlebih dahulu. Gunakan limiter/proteksi perangkat keras dan hindari feedback akustik. Jangan menganggap aplikasi ini sudah siap produksi.

## Saran pengembangan berikutnya
Tambahkan device selector memakai Oboe device IDs, pengukuran xrun/latency, analyzer dari data audio, parameter threshold, limiter true-peak, preset, dan pengujian audio loopback.


## Audio start / troubleshooting
- Tap **START** and grant the microphone permission.
- The engine now tries stereo then mono input, and retries using the device-native input sample rate. This is important because many phone microphones expose mono capture only.
- Connect a wired or USB headset before pressing START when possible. Bluetooth routing depends on Android/device support and may add substantial latency.
- If the status changes to `AUDIO DEVICE OPEN FAILED`, capture the GitHub Actions build log and the Android device model/Android version. A successful APK build does not guarantee that every device exposes a compatible full-duplex audio route.
- The spectrum graphic in this starter is a visual placeholder; it is not yet a live FFT analyzer.


## Permission behavior (Fix 2)
- On the first press of START, Android displays its microphone permission prompt.
- Select **Allow** / **While using the app**. The app then starts the Oboe engine automatically.
- If permission was already granted, START skips the prompt and starts immediately.
- If permission is denied, open Android Settings → Apps → EquaTube DSP → Permissions → Microphone → Allow, then return and press START again.
- Android microphone privacy toggle must also be enabled.


## Internal audio input (Android 10+)
- Uses the Android MediaProjection consent dialog and AudioPlaybackCapture/AudioRecord.
- Captures eligible `USAGE_MEDIA` and `USAGE_GAME` playback as Float PCM.
- A Kotlin capture thread feeds PCM into the native ring buffer; Oboe provides low-latency output and C++ DSP.
- No microphone permission is required for this input mode.
- The user must approve a new capture session when starting.
- Android only exposes playback from source apps that permit capture. Apps that opt out, DRM-protected content, calls and some system audio cannot be captured.
- This is not a universal system-wide equalizer. It processes only playback made available through Android Playback Capture.
- Minimum Android version is Android 10 (API 29). Bluetooth routing and latency depend on the device and Android.
- Keep the app visible during capture in this starter build.

## Build
Use `.github/workflows/build.yml` in the repository. Download the `EquaTubeDSP-APK` artifact after a successful GitHub Actions run.

- A `mediaProjection` foreground service and persistent notification are included for Android 14+ requirements.
