# EquaTube DSP — starter project

Proyek starter Android dengan Kotlin + Jetpack Compose + C++17 + Google Oboe.

## Buka di Android Studio
1. Ekstrak ZIP, lalu pilih **Open** dan arahkan ke folder `EquaTubeDSP`.
2. Install Android SDK Platform 36, NDK (Side by side), CMake 3.22.1, dan JDK 17 dari SDK Manager.
3. Sinkronkan Gradle. Pada konfigurasi CMake pertama, koneksi internet diperlukan agar FetchContent mengunduh Oboe `1.9.3`.
4. Jalankan pada perangkat Android fisik. Berikan izin mikrofon, lalu tekan START.

## Struktur utama
- `app/src/main/java/com/example/equatubedsp/MainActivity.kt` — UI Compose dan JNI declarations.
- `app/src/main/cpp/AudioEngine.h/.cpp` — stream Oboe, ring buffer SPSC, DSP.
- `app/src/main/cpp/native-lib.cpp` — JNI.
- `app/src/main/cpp/CMakeLists.txt` — FetchContent Oboe dan native build.
- `app/build.gradle.kts` — Android/Compose/NDK configuration.

## Catatan implementasi dan batasan
- Input dan output dibuka sebagai Float PCM stereo, LowLatency, dan meminta Exclusive. Jika Exclusive ditolak oleh perangkat/driver, kode mencoba Shared.
- Input callback menulis ke ring buffer SPSC; output callback membaca dan memprosesnya. Callback tidak memakai mutex, alokasi heap, logging, atau operasi I/O.
- Parameter slider disimpan sebagai atomik. UI mengirim perubahan melalui JNI; audio callback membaca snapshot atomik.
- DSP saat ini berisi crossover lima band sederhana (SUB/LOW/MID/HIGH/AIR), compressor soft-knee dasar (threshold tetap -12 dB), dan gain output. Ini fondasi/rujukan, bukan mastering-grade DSP.
- Spectrum monitor saat ini hanya visual placeholder, bukan analyzer dari sampel audio.
- RATIO/KNEE/ATTACK/RELEASE mengendalikan compressor sederhana. GAIN berupa pengali linear 0–2.5×.
- Routing input USB/soundcard bergantung pada dukungan Android, driver, izin, dan pemilihan perangkat oleh sistem. Starter ini memakai default input/output route; belum menyediakan pemilih perangkat USB.
- Latensi round-trip tidak dapat dijamin. Ukur pada perangkat target; exclusive/low-latency adalah permintaan, bukan jaminan.
- Untuk live PA, uji dengan volume rendah terlebih dahulu. Gunakan limiter/proteksi perangkat keras dan hindari feedback akustik. Jangan menganggap aplikasi ini sudah siap produksi.

## Saran pengembangan berikutnya
Tambahkan device selector memakai Oboe device IDs, pengukuran xrun/latency, analyzer dari data audio, parameter threshold, limiter true-peak, preset, dan pengujian audio loopback.
