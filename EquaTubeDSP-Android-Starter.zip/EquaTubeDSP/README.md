# EquaTube DSP

A starter Android audio processor using Kotlin + Jetpack Compose + Android NDK C++17 + Google Oboe.

## Build in Android Studio

1. Extract this ZIP.
2. Open the extracted `EquaTubeDSP` folder in Android Studio.
3. Use JDK 17.
4. Allow Android Studio to install Android SDK 36, NDK `27.2.12479018`, and CMake `3.22.1`.
5. Sync Gradle, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The project uses Gradle 8.13 and Android Gradle Plugin 8.13.2.

## Build with GitHub Actions

Upload the contents of this folder to the root of a GitHub repository. The workflow at `.github/workflows/android.yml` builds a debug APK. Open **Actions**, run **Build EquaTube DSP APK**, then download the `EquaTubeDSP-APK` artifact.

## Audio routing and important limitations

- This starter processes live microphone / USB audio input and sends the processed signal to Android's currently selected output device.
- Wired headsets, USB audio devices, and Bluetooth output depend on Android's device routing. Select the desired output device in Android's system media/output switcher.
- Bluetooth adds codec and radio buffering latency; it is not a low-latency monitoring path.
- Android does not allow an ordinary third-party app to transparently equalize every other app's system audio. This project does not capture or modify all music playing from other apps. It processes its own live input-to-output audio path.
- The spectrum panel is a visual demo meter, not yet a measured FFT analyzer.
- The five EQ switches enable/disable five fixed peaking filters. They are starter values, not a calibrated room/speaker correction system.
- Request microphone permission and use headphones during testing to reduce acoustic feedback. Start with low output volume.
- Some USB interfaces expose only mono input, some require a powered USB hub, and some devices do not support exclusive mode. The engine automatically retries shared mode if exclusive mode is unavailable.

## DSP notes

The native audio callback uses a lock-free single-producer/single-consumer ring buffer between input and output callbacks. Slider values are transferred using atomics. Avoid memory allocation, file I/O, logging, or mutex locking in the audio callback. The callback uses preallocated scratch storage and atomic parameter reads; continue profiling on target devices before production deployment.

## Production work still recommended

- Replace the demo spectrum with an FFT analyzer.
- Add calibration, adjustable EQ frequency/Q/gain, limiter, clipping indicators, and device selection.
- Add lifecycle/audio-focus handling and robust stream-disconnect recovery.
- Test on real Android devices and USB/Bluetooth hardware before live performance.
