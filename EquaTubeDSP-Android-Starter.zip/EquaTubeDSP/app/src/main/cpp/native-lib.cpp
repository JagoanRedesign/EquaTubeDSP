#include <jni.h>
#include <memory>
#include <mutex>
#include "AudioEngine.h"

namespace {
std::mutex gMutex;
std::unique_ptr<AudioEngine> gEngine;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_equatube_dsp_NativeAudio_nativeStart(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(gMutex);
    if (!gEngine) gEngine = std::make_unique<AudioEngine>();
    return gEngine->start() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_equatube_dsp_NativeAudio_nativeStop(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(gMutex);
    if (gEngine) gEngine->stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_equatube_dsp_NativeAudio_nativeSetDynamics(
        JNIEnv *, jobject, jfloat ratio, jfloat knee,
        jfloat attack, jfloat release, jfloat gain) {
    std::lock_guard<std::mutex> lock(gMutex);
    if (gEngine) gEngine->setDynamics(ratio, knee, attack, release, gain);
}

extern "C" JNIEXPORT void JNICALL
Java_com_equatube_dsp_NativeAudio_nativeSetBand(
        JNIEnv *, jobject, jint band, jboolean enabled) {
    std::lock_guard<std::mutex> lock(gMutex);
    if (gEngine) gEngine->setBandEnabled(band, enabled == JNI_TRUE);
}
