#include "AudioEngine.h"

#include <jni.h>
#include <memory>
#include <mutex>

namespace {
std::mutex gEngineMutex;
std::unique_ptr<AudioEngine> gEngine;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_equatubedsp_MainActivity_nativeStartEngine(
    JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (!gEngine) gEngine = std::make_unique<AudioEngine>();
    return gEngine->start() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_equatubedsp_MainActivity_nativeStopEngine(
    JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (gEngine) gEngine->stop();
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_equatubedsp_MainActivity_nativeSetParameters(
    JNIEnv*, jobject, jfloat ratio, jfloat knee,
    jfloat attack, jfloat release, jfloat gain) {
    // The callback reads lock-free atomics. The mutex only protects lifetime
    // while start/stop is being coordinated with JNI calls.
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (gEngine) gEngine->setParameters(ratio, knee, attack, release, gain);
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_equatubedsp_MainActivity_nativeSetFilterMask(
    JNIEnv*, jobject, jint mask) {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    if (gEngine) gEngine->setFilterMask(mask);
}
