#pragma once

#include <oboe/Oboe.h>
#include <array>
#include <atomic>
#include <memory>
#include <vector>

class AudioEngine final : public oboe::AudioStreamDataCallback {
public:
    AudioEngine() = default;
    ~AudioEngine();

    bool start();
    void stop();

    void setDynamics(float ratio, float knee, float attackMs,
                     float releaseMs, float gainDb);
    void setBandEnabled(int band, bool enabled);
    bool isRunning() const { return running_.load(); }

    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream *stream, void *audioData, int32_t numFrames) override;

private:
    static constexpr uint32_t kRingCapacity = 32768;
    class RingBuffer {
    public:
        void reset();
        void push(const float *src, uint32_t count);
        uint32_t pop(float *dst, uint32_t count);
    private:
        std::array<float, kRingCapacity> data_{};
        std::atomic<uint32_t> write_{0};
        std::atomic<uint32_t> read_{0};
    };

    class InputCallback final : public oboe::AudioStreamDataCallback {
    public:
        explicit InputCallback(AudioEngine *owner) : owner_(owner) {}
        oboe::DataCallbackResult onAudioReady(
            oboe::AudioStream *stream, void *audioData, int32_t numFrames) override;
    private:
        AudioEngine *owner_;
    };

    struct Biquad {
        float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
        float z1[2]{0, 0};
        float z2[2]{0, 0};
        float process(float x, int channel);
    };

    static Biquad makePeaking(float sampleRate, float frequency,
                              float q, float gainDb);

    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;
    std::shared_ptr<InputCallback> inputCallback_;
    RingBuffer ring_;

    std::atomic<bool> running_{false};
    std::atomic<float> ratio_{3.0f};
    std::atomic<float> kneeDb_{6.0f};
    std::atomic<float> attackMs_{12.0f};
    std::atomic<float> releaseMs_{180.0f};
    std::atomic<float> gainDb_{0.0f};
    std::array<std::atomic<bool>, 5> bandEnabled_{
        true, true, true, true, true
    };

    std::array<Biquad, 5> filters_;
    // Preallocated callback scratch space: no heap allocation on the audio thread.
    std::array<float, 8192> inputScratch_{};
    float envelope_ = 0.0f;
    float sampleRate_ = 48000.0f;
    int inputChannels_ = 1;
    int outputChannels_ = 2;
};
