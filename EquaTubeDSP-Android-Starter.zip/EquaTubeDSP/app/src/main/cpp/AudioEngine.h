#pragma once

#include <oboe/Oboe.h>
#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <vector>

class AudioEngine final : public oboe::AudioStreamDataCallback {
public:
    AudioEngine() = default;
    ~AudioEngine() override;

    bool start();
    bool startPlaybackCapture();
    void pushPlaybackInput(const float* input, int32_t frames, int32_t channels) noexcept;
    void stop();

    void setParameters(float ratio, float knee, float attackMs,
                       float releaseMs, float gainLinear) noexcept;
    void setFilterMask(int mask) noexcept;

    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* stream, void* audioData,
        int32_t numFrames) override;

private:
    static constexpr uint32_t kRingFrames = 32768; // power of two
    static constexpr uint32_t kRingMask = kRingFrames - 1;
    static constexpr uint32_t kChannels = 2;

    bool openOutput();
    bool openInput();
    bool openWithFallback(oboe::AudioStreamBuilder& builder,
                          std::shared_ptr<oboe::AudioStream>& stream);

    void captureInput(const float* input, int32_t frames,
                      int32_t inputChannels) noexcept;
    void renderOutput(float* output, int32_t frames,
                      int32_t outputChannels) noexcept;
    float processSample(float input, int channel) noexcept;
    float lowPass(float input, float cutoff, int channel,
                  int stage) noexcept;

    std::shared_ptr<oboe::AudioStream> inputStream_;
    std::shared_ptr<oboe::AudioStream> outputStream_;

    // Single-producer (input callback), single-consumer (output callback).
    std::unique_ptr<float[]> ring_;
    alignas(64) std::atomic<uint64_t> writeIndex_{0};
    alignas(64) std::atomic<uint64_t> readIndex_{0};

    std::atomic<float> ratio_{4.0f};
    std::atomic<float> knee_{6.0f};
    std::atomic<float> attackMs_{10.0f};
    std::atomic<float> releaseMs_{100.0f};
    std::atomic<float> gain_{1.0f};
    std::atomic<int> filterMask_{0};

    float envelope_[2] = {0.0f, 0.0f};
    float lowPassState_[2][4] = {};
    float sampleRate_ = 48000.0f;
    float lowPassAlpha_[4] = {};
    float cachedAttackMs_ = -1.0f; // accessed only by the output callback
    float cachedReleaseMs_ = -1.0f;
    float attackCoeff_ = 0.0f;
    float releaseCoeff_ = 0.0f;

    enum class StreamRole { Input, Output };
};
