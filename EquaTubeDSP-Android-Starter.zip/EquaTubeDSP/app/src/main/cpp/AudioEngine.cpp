#include "AudioEngine.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <new>

namespace {
constexpr float kPi = 3.14159265358979323846f;
constexpr float kThresholdDb = -12.0f;
constexpr float kMinGain = 0.0f;
constexpr float kMaxGain = 2.5f;
}

AudioEngine::~AudioEngine() {
    stop();
}

bool AudioEngine::openWithFallback(
    oboe::AudioStreamBuilder& builder,
    std::shared_ptr<oboe::AudioStream>& stream) {

    builder.setSharingMode(oboe::SharingMode::Exclusive);
    oboe::Result result = builder.openStream(stream);
    if (result == oboe::Result::OK) return true;

    // Exclusive/MMAP is a request, not a guarantee. Retry shared mode so
    // devices or USB interfaces that reject exclusive mode can still work.
    builder.setSharingMode(oboe::SharingMode::Shared);
    result = builder.openStream(stream);
    return result == oboe::Result::OK;
}

bool AudioEngine::openOutput() {
    oboe::AudioStreamBuilder builder;
    builder.setDirection(oboe::Direction::Output);
    builder.setFormat(oboe::AudioFormat::Float);
    builder.setChannelCount(oboe::ChannelCount::Stereo);
    builder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
    builder.setSharingMode(oboe::SharingMode::Exclusive);
    builder.setDataCallback(this);

    if (!openWithFallback(builder, outputStream_)) return false;

    sampleRate_ = static_cast<float>(outputStream_->getSampleRate());
    if (sampleRate_ <= 0.0f) sampleRate_ = 48000.0f;

    const float cutoffs[4] = {100.0f, 250.0f, 4000.0f, 10000.0f};
    for (int i = 0; i < 4; ++i) {
        const float cutoff = std::min(cutoffs[i], sampleRate_ * 0.45f);
        lowPassAlpha_[i] = 1.0f - std::exp(-2.0f * kPi * cutoff / sampleRate_);
    }
    cachedAttackMs_ = -1.0f;
    cachedReleaseMs_ = -1.0f;
    return true;
}

bool AudioEngine::openInput() {
    // Many Android microphones expose mono input only. Try the preferred
    // stereo/48 kHz path first, then progressively relax channel/rate requests.
    // Oboe still converts the stream to Float PCM for the DSP callback.
    const oboe::ChannelCount channelOptions[] = {
        oboe::ChannelCount::Stereo,
        oboe::ChannelCount::Mono
    };
    const int32_t rateOptions[] = {
        static_cast<int32_t>(sampleRate_),
        0 // Let Android choose the device-native input rate.
    };

    for (const auto channels : channelOptions) {
        for (const auto rate : rateOptions) {
            oboe::AudioStreamBuilder builder;
            builder.setDirection(oboe::Direction::Input);
            builder.setFormat(oboe::AudioFormat::Float);
            builder.setChannelCount(channels);
            if (rate > 0) builder.setSampleRate(rate);
            builder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
            builder.setInputPreset(oboe::InputPreset::Unprocessed);
            builder.setDataCallback(this);

            if (openWithFallback(builder, inputStream_)) {
                return true;
            }
            if (inputStream_) {
                inputStream_->close();
                inputStream_.reset();
            }
        }
    }
    return false;
}

bool AudioEngine::startPlaybackCapture() {
    stop();
    ring_.reset(new (std::nothrow) float[kRingFrames * kChannels]());
    if (!ring_) return false;
    writeIndex_.store(0, std::memory_order_relaxed);
    readIndex_.store(0, std::memory_order_relaxed);
    envelope_[0] = envelope_[1] = 0.0f;
    std::memset(lowPassState_, 0, sizeof(lowPassState_));

    // Android Playback Capture supplies PCM from Kotlin. Oboe handles output.
    if (!openOutput()) {
        stop();
        return false;
    }
    if (outputStream_->requestStart() != oboe::Result::OK) {
        stop();
        return false;
    }
    return true;
}

void AudioEngine::pushPlaybackInput(
    const float* input, int32_t frames, int32_t channels) noexcept {
    captureInput(input, frames, channels);
}

bool AudioEngine::start() {
    stop();

    ring_.reset(new (std::nothrow) float[kRingFrames * kChannels]());
    if (!ring_) return false;
    writeIndex_.store(0, std::memory_order_relaxed);
    readIndex_.store(0, std::memory_order_relaxed);
    envelope_[0] = envelope_[1] = 0.0f;
    std::memset(lowPassState_, 0, sizeof(lowPassState_));

    if (!openOutput()) {
        stop();
        return false;
    }
    if (!openInput()) {
        stop();
        return false;
    }

    // Start capture before playback so the first output callbacks can consume
    // data as soon as it arrives.
    if (inputStream_->requestStart() != oboe::Result::OK) {
        stop();
        return false;
    }
    if (outputStream_->requestStart() != oboe::Result::OK) {
        stop();
        return false;
    }
    return true;
}

void AudioEngine::stop() {
    if (outputStream_) {
        outputStream_->requestStop();
        outputStream_->close();
        outputStream_.reset();
    }
    if (inputStream_) {
        inputStream_->requestStop();
        inputStream_->close();
        inputStream_.reset();
    }
    ring_.reset();
    writeIndex_.store(0, std::memory_order_relaxed);
    readIndex_.store(0, std::memory_order_relaxed);
}

void AudioEngine::setParameters(float ratio, float knee, float attackMs,
                                float releaseMs, float gainLinear) noexcept {
    ratio_.store(std::clamp(ratio, 1.0f, 20.0f), std::memory_order_relaxed);
    knee_.store(std::clamp(knee, 0.0f, 12.0f), std::memory_order_relaxed);
    attackMs_.store(std::clamp(attackMs, 1.0f, 100.0f), std::memory_order_relaxed);
    releaseMs_.store(std::clamp(releaseMs, 10.0f, 500.0f), std::memory_order_relaxed);
    gain_.store(std::clamp(gainLinear, kMinGain, kMaxGain), std::memory_order_relaxed);

    // Coefficients are recalculated in the callback from the current values;
    // no locks or stream operations are performed from the UI thread.
}

void AudioEngine::setFilterMask(int mask) noexcept {
    filterMask_.store(mask & 0x1F, std::memory_order_relaxed);
}

void AudioEngine::captureInput(const float* input, int32_t frames,
                               int32_t inputChannels) noexcept {
    if (!ring_ || input == nullptr || frames <= 0) return;

    uint64_t write = writeIndex_.load(std::memory_order_relaxed);
    const uint64_t read = readIndex_.load(std::memory_order_acquire);
    const uint64_t capacity = static_cast<uint64_t>(kRingFrames) * kChannels;
    const uint64_t available = capacity - (write - read);
    const uint64_t requested = static_cast<uint64_t>(frames) * kChannels;
    const int32_t framesToCopy = static_cast<int32_t>(
        std::min<uint64_t>(static_cast<uint64_t>(frames), available / kChannels));

    for (int32_t frame = 0; frame < framesToCopy; ++frame) {
        const float left = input[frame * inputChannels];
        const float right = (inputChannels > 1)
            ? input[frame * inputChannels + 1] : left;

        ring_[write & (capacity - 1)] = left;
        ++write;
        ring_[write & (capacity - 1)] = right;
        ++write;
    }

    (void)requested; // Excess input frames are dropped rather than blocking.
    writeIndex_.store(write, std::memory_order_release);
}

void AudioEngine::renderOutput(float* output, int32_t frames,
                               int32_t outputChannels) noexcept {
    if (output == nullptr || frames <= 0) return;

    const uint64_t capacity = static_cast<uint64_t>(kRingFrames) * kChannels;
    uint64_t read = readIndex_.load(std::memory_order_relaxed);
    const uint64_t write = writeIndex_.load(std::memory_order_acquire);
    const uint64_t availableFrames = (write - read) / kChannels;

    for (int32_t frame = 0; frame < frames; ++frame) {
        float left = 0.0f;
        float right = 0.0f;

        if (static_cast<uint64_t>(frame) < availableFrames) {
            left = ring_[read & (capacity - 1)];
            ++read;
            right = ring_[read & (capacity - 1)];
            ++read;
        }

        left = processSample(left, 0);
        right = processSample(right, 1);

        if (outputChannels == 1) {
            output[frame] = 0.5f * (left + right);
        } else {
            output[frame * outputChannels] = left;
            output[frame * outputChannels + 1] = right;
            for (int channel = 2; channel < outputChannels; ++channel) {
                output[frame * outputChannels + channel] = 0.5f * (left + right);
            }
        }
    }

    readIndex_.store(read, std::memory_order_release);
}

float AudioEngine::lowPass(float input, float cutoff, int channel,
                           int stage) noexcept {
    (void) cutoff; // Coefficients are prepared once when the stream opens.
    float& state = lowPassState_[channel][stage];
    state += lowPassAlpha_[stage] * (input - state);
    return state;
}

float AudioEngine::processSample(float input, int channel) noexcept {
    // Five simple crossover bands: SUB <100 Hz, LOW 100-250 Hz,
    // MID 250-4 kHz, HIGH 4-10 kHz, AIR >10 kHz.
    const int mask = filterMask_.load(std::memory_order_relaxed);
    if (mask != 0) {
        const float lp100 = lowPass(input, 100.0f, channel, 0);
        const float lp250 = lowPass(input, 250.0f, channel, 1);
        const float lp4k = lowPass(input, 4000.0f, channel, 2);
        const float lp10k = lowPass(input, 10000.0f, channel, 3);
        float selected = 0.0f;
        if (mask & (1 << 0)) selected += lp100;
        if (mask & (1 << 1)) selected += (lp250 - lp100);
        if (mask & (1 << 2)) selected += (lp4k - lp250);
        if (mask & (1 << 3)) selected += (lp10k - lp4k);
        if (mask & (1 << 4)) selected += (input - lp10k);
        input = selected;
    }

    const float currentAttackMs = attackMs_.load(std::memory_order_relaxed);
    const float currentReleaseMs = releaseMs_.load(std::memory_order_relaxed);
    if (currentAttackMs != cachedAttackMs_) {
        const float seconds = std::max(0.001f, currentAttackMs / 1000.0f);
        attackCoeff_ = std::exp(-1.0f / (seconds * sampleRate_));
        cachedAttackMs_ = currentAttackMs;
    }
    if (currentReleaseMs != cachedReleaseMs_) {
        const float seconds = std::max(0.001f, currentReleaseMs / 1000.0f);
        releaseCoeff_ = std::exp(-1.0f / (seconds * sampleRate_));
        cachedReleaseMs_ = currentReleaseMs;
    }

    const float magnitude = std::fabs(input);
    float& env = envelope_[channel];
    const float coeff = (magnitude > env) ? attackCoeff_ : releaseCoeff_;
    env = coeff * env + (1.0f - coeff) * magnitude;

    const float levelDb = 20.0f * std::log10(std::max(env, 1.0e-6f));
    const float ratio = ratio_.load(std::memory_order_relaxed);
    const float knee = knee_.load(std::memory_order_relaxed);
    const float over = levelDb - kThresholdDb;
    float compressedDb = 0.0f;

    if (knee <= 0.001f) {
        if (over > 0.0f) compressedDb = over * (1.0f - 1.0f / ratio);
    } else if (over > -0.5f * knee) {
        if (over >= 0.5f * knee) {
            compressedDb = over * (1.0f - 1.0f / ratio);
        } else {
            const float x = over + 0.5f * knee;
            compressedDb = (x * x / (2.0f * knee)) * (1.0f - 1.0f / ratio);
        }
    }

    const float compressionGain = std::pow(10.0f, -compressedDb / 20.0f);
    const float output = input * compressionGain * gain_.load(std::memory_order_relaxed);
    return std::clamp(output, -1.0f, 1.0f);
}

oboe::DataCallbackResult AudioEngine::onAudioReady(
    oboe::AudioStream* stream, void* audioData, int32_t numFrames) {

    if (stream == inputStream_.get()) {
        captureInput(static_cast<const float*>(audioData),
                     numFrames, stream->getChannelCount());
    } else if (stream == outputStream_.get()) {
        renderOutput(static_cast<float*>(audioData),
                     numFrames, stream->getChannelCount());
    }
    return oboe::DataCallbackResult::Continue;
}
