#include "AudioEngine.h"
#include <algorithm>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "EquaTubeDSP"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {
constexpr float kPi = 3.14159265358979323846f;
constexpr float kThreshold = 0.12589254f; // -18 dBFS
}

AudioEngine::~AudioEngine() { stop(); }

void AudioEngine::RingBuffer::reset() {
    read_.store(0, std::memory_order_relaxed);
    write_.store(0, std::memory_order_relaxed);
}

void AudioEngine::RingBuffer::push(const float *src, uint32_t count) {
    uint32_t w = write_.load(std::memory_order_relaxed);
    uint32_t r = read_.load(std::memory_order_acquire);
    for (uint32_t i = 0; i < count; ++i) {
        if ((w - r) >= kRingCapacity) break; // Drop newest samples if full.
        data_[w % kRingCapacity] = src[i];
        ++w;
    }
    write_.store(w, std::memory_order_release);
}

uint32_t AudioEngine::RingBuffer::pop(float *dst, uint32_t count) {
    uint32_t r = read_.load(std::memory_order_relaxed);
    const uint32_t w = write_.load(std::memory_order_acquire);
    uint32_t available = std::min(count, w - r);
    for (uint32_t i = 0; i < available; ++i) {
        dst[i] = data_[r % kRingCapacity];
        ++r;
    }
    read_.store(r, std::memory_order_release);
    return available;
}

oboe::DataCallbackResult AudioEngine::InputCallback::onAudioReady(
        oboe::AudioStream *, void *audioData, int32_t numFrames) {
    if (!audioData || numFrames <= 0) return oboe::DataCallbackResult::Continue;
    const auto *input = static_cast<const float *>(audioData);
    owner_->ring_.push(input, static_cast<uint32_t>(numFrames * owner_->inputChannels_));
    return oboe::DataCallbackResult::Continue;
}

float AudioEngine::Biquad::process(float x, int channel) {
    float y = b0 * x + z1[channel];
    z1[channel] = b1 * x - a1 * y + z2[channel];
    z2[channel] = b2 * x - a2 * y;
    return y;
}

AudioEngine::Biquad AudioEngine::makePeaking(
        float sr, float frequency, float q, float gainDb) {
    Biquad f;
    const float a = std::pow(10.0f, gainDb / 40.0f);
    const float w0 = 2.0f * kPi * frequency / sr;
    const float alpha = std::sin(w0) / (2.0f * q);
    const float cosw = std::cos(w0);
    const float a0 = 1.0f + alpha / a;
    f.b0 = (1.0f + alpha * a) / a0;
    f.b1 = (-2.0f * cosw) / a0;
    f.b2 = (1.0f - alpha * a) / a0;
    f.a1 = (-2.0f * cosw) / a0;
    f.a2 = (1.0f - alpha / a) / a0;
    return f;
}

bool AudioEngine::start() {
    if (running_.load()) return true;
    ring_.reset();
    inputCallback_ = std::make_shared<InputCallback>(this);

    oboe::AudioStreamBuilder inputBuilder;
    inputBuilder.setDirection(oboe::Direction::Input)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Stereo)
        ->setSampleRate(48000)
        ->setDataCallback(inputCallback_.get());

    oboe::Result result = inputBuilder.openStream(inputStream_);
    if (result != oboe::Result::OK) {
        inputBuilder.setSharingMode(oboe::SharingMode::Shared);
        result = inputBuilder.openStream(inputStream_);
    }
    if (result != oboe::Result::OK) {
        LOGE("Unable to open input stream: %s", oboe::convertToText(result));
        inputStream_.reset();
        return false;
    }

    inputChannels_ = inputStream_->getChannelCount();
    sampleRate_ = static_cast<float>(inputStream_->getSampleRate());

    oboe::AudioStreamBuilder outputBuilder;
    outputBuilder.setDirection(oboe::Direction::Output)
        ->setPerformanceMode(oboe::PerformanceMode::LowLatency)
        ->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)
        ->setChannelCount(oboe::ChannelCount::Stereo)
        ->setSampleRate(48000)
        ->setDataCallback(this);

    result = outputBuilder.openStream(outputStream_);
    if (result != oboe::Result::OK) {
        outputBuilder.setSharingMode(oboe::SharingMode::Shared);
        result = outputBuilder.openStream(outputStream_);
    }
    if (result != oboe::Result::OK) {
        LOGE("Unable to open output stream: %s", oboe::convertToText(result));
        inputStream_->close();
        inputStream_.reset();
        outputStream_.reset();
        return false;
    }

    outputChannels_ = outputStream_->getChannelCount();
    sampleRate_ = static_cast<float>(outputStream_->getSampleRate());
    const float centers[5] = {60.0f, 180.0f, 1000.0f, 4500.0f, 11000.0f};
    for (int i = 0; i < 5; ++i) {
        filters_[i] = makePeaking(sampleRate_, centers[i], 0.85f, 4.0f);
    }

    if (inputStream_->requestStart() != oboe::Result::OK) {
        stop();
        return false;
    }
    if (outputStream_->requestStart() != oboe::Result::OK) {
        stop();
        return false;
    }
    running_.store(true);
    return true;
}

void AudioEngine::stop() {
    running_.store(false);
    if (outputStream_) {
        outputStream_->requestStop();
        outputStream_->close();
        outputStream_.reset();
    }
    if (inputStream_) {
        inputStream_->requestStop();
        inputStream_->close();
        inputStream_.reset();
    }
    inputCallback_.reset();
}

void AudioEngine::setDynamics(float ratio, float knee, float attackMs,
                              float releaseMs, float gainDb) {
    ratio_.store(std::clamp(ratio, 1.0f, 20.0f), std::memory_order_relaxed);
    kneeDb_.store(std::clamp(knee, 0.0f, 18.0f), std::memory_order_relaxed);
    attackMs_.store(std::clamp(attackMs, 0.1f, 200.0f), std::memory_order_relaxed);
    releaseMs_.store(std::clamp(releaseMs, 5.0f, 1500.0f), std::memory_order_relaxed);
    gainDb_.store(std::clamp(gainDb, -12.0f, 12.0f), std::memory_order_relaxed);
}

void AudioEngine::setBandEnabled(int band, bool enabled) {
    if (band >= 0 && band < 5) bandEnabled_[band].store(enabled, std::memory_order_relaxed);
}

oboe::DataCallbackResult AudioEngine::onAudioReady(
        oboe::AudioStream *, void *audioData, int32_t numFrames) {
    auto *output = static_cast<float *>(audioData);
    if (!output || numFrames <= 0) return oboe::DataCallbackResult::Continue;

    const int channels = std::max(1, outputChannels_);
    const uint32_t wanted = static_cast<uint32_t>(numFrames * inputChannels_);
    if (wanted > inputScratch_.size()) {
        std::fill(output, output + numFrames * channels, 0.0f);
        return oboe::DataCallbackResult::Continue;
    }
    const uint32_t received = ring_.pop(inputScratch_.data(), wanted);

    const float ratio = ratio_.load(std::memory_order_relaxed);
    const float knee = kneeDb_.load(std::memory_order_relaxed);
    const float attack = attackMs_.load(std::memory_order_relaxed);
    const float release = releaseMs_.load(std::memory_order_relaxed);
    const float makeup = std::pow(10.0f, gainDb_.load(std::memory_order_relaxed) / 20.0f);
    const float attackCoeff = std::exp(-1.0f / (0.001f * attack * sampleRate_));
    const float releaseCoeff = std::exp(-1.0f / (0.001f * release * sampleRate_));
    const float kneeLinear = std::pow(10.0f, knee / 20.0f);

    for (int frame = 0; frame < numFrames; ++frame) {
        float frameSamples[2] = {0.0f, 0.0f};
        for (int ch = 0; ch < channels; ++ch) {
            const int inCh = inputChannels_ > 1 ? std::min(ch, inputChannels_ - 1) : 0;
            const uint32_t idx = static_cast<uint32_t>(frame * inputChannels_ + inCh);
            if (idx < received) frameSamples[ch] = inputScratch_[idx];
        }

        float detector = 0.0f;
        for (int ch = 0; ch < channels; ++ch) detector = std::max(detector, std::abs(frameSamples[ch]));
        const float coeff = detector > envelope_ ? attackCoeff : releaseCoeff;
        envelope_ = coeff * envelope_ + (1.0f - coeff) * detector;

        float compGain = 1.0f;
        if (envelope_ > kThreshold) {
            const float over = envelope_ / kThreshold;
            const float soft = std::max(0.0f, std::log(over) - std::log(kneeLinear) * 0.5f);
            compGain = std::pow(over, (1.0f / ratio) - 1.0f);
            if (knee > 0.0f && over < kneeLinear) {
                const float blend = std::clamp(soft / std::max(0.0001f, std::log(kneeLinear) * 0.5f), 0.0f, 1.0f);
                compGain = 1.0f + (compGain - 1.0f) * blend;
            }
        }

        for (int ch = 0; ch < channels; ++ch) {
            float x = frameSamples[ch] * compGain * makeup;
            for (int band = 0; band < 5; ++band) {
                if (bandEnabled_[band].load(std::memory_order_relaxed)) {
                    x = filters_[band].process(x, std::min(ch, 1));
                }
            }
            output[frame * channels + ch] = std::clamp(x, -0.98f, 0.98f);
        }
    }
    return oboe::DataCallbackResult::Continue;
}
