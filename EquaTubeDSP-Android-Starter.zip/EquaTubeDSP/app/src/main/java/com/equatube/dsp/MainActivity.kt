package com.equatube.dsp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

private val Bg = Color(0xFF080D16)
private val Panel = Color(0xFF101A29)
private val Cyan = Color(0xFF27D9F2)
private val Blue = Color(0xFF278BFF)
private val Green = Color(0xFF28E59A)
private val Muted = Color(0xFF7890A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EquaTubeApp() }
    }

    override fun onDestroy() {
        NativeAudio.nativeStop()
        super.onDestroy()
    }
}

@Composable
private fun EquaTubeApp() {
    val context = LocalContext.current
    var running by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("AUDIO ENGINE READY") }
    var ratio by remember { mutableFloatStateOf(3f) }
    var knee by remember { mutableFloatStateOf(6f) }
    var attack by remember { mutableFloatStateOf(12f) }
    var release by remember { mutableFloatStateOf(180f) }
    var gain by remember { mutableFloatStateOf(0f) }
    val bands = remember { mutableStateListOf(true, true, true, true, true) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            running = NativeAudio.nativeStart()
            status = if (running) "LIVE AUDIO • LOW LATENCY" else "AUDIO START FAILED"
        } else {
            status = "MICROPHONE PERMISSION REQUIRED"
        }
    }

    fun updateNative() {
        NativeAudio.nativeSetDynamics(ratio, knee, attack, release, gain)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan,
        background = Bg,
        surface = Panel
    )) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF111E30), Bg, Color(0xFF05080E))))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("EQUATUBE", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("DSP  •  LIVE AUDIO PROCESSOR", color = Cyan, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
                Text("R4TIM", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            SpectrumPanel()

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("5-BAND EQUALIZER", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text("STEREO LINK: ON", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("SUB", "LOW", "MID", "HIGH", "AIR").forEachIndexed { index, label ->
                    val active = bands[index]
                    Surface(
                        onClick = {
                            bands[index] = !bands[index]
                            NativeAudio.nativeSetBand(index, bands[index])
                        },
                        modifier = Modifier.weight(1f).height(43.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = if (active) Color(0xFF087EA4) else Color(0xFF172234),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) Cyan else Color(0xFF34465D))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(label, color = if (active) Color.White else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Text("DYNAMIC PROCESSOR", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(
                modifier = Modifier.weight(1f).fillMaxWidth()
                    .background(Color(0xAA0B1422), RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF243D58), RoundedCornerShape(16.dp))
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.Stretch
            ) {
                Fader("RATIO", ratio, "x", 1f, 20f, Modifier.weight(1f)) { ratio = it; updateNative() }
                Fader("KNEE", knee, "dB", 0f, 18f, Modifier.weight(1f)) { knee = it; updateNative() }
                Fader("ATTACK", attack, "ms", 0.1f, 100f, Modifier.weight(1f)) { attack = it; updateNative() }
                Fader("RELEASE", release, "ms", 5f, 600f, Modifier.weight(1f)) { release = it; updateNative() }
                Fader("GAIN", gain, "dB", -12f, 12f, Modifier.weight(1f)) { gain = it; updateNative() }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(status, color = if (running) Green else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("Input: microphone / USB audio • Output: system selected device", color = Muted, fontSize = 9.sp)
                }
                Button(
                    onClick = {
                        if (running) {
                            NativeAudio.nativeStop()
                            running = false
                            status = "ENGINE STOPPED"
                        } else {
                            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                            if (granted) {
                                running = NativeAudio.nativeStart()
                                status = if (running) "LIVE AUDIO • LOW LATENCY" else "AUDIO START FAILED"
                            } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (running) Color(0xFF9C3344) else Color(0xFF087EA4)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (running) "STOP" else "START", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun SpectrumPanel() {
    val transition = rememberInfiniteTransition(label = "spectrum")
    val pulse by transition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Column(
        modifier = Modifier.fillMaxWidth()
            .background(Color(0xFF050B13), RoundedCornerShape(14.dp))
            .border(1.dp, Color(0xFF1B7894), RoundedCornerShape(14.dp))
            .padding(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("REALTIME SPECTRUM", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("48 kHz • STEREO", color = Muted, fontSize = 9.sp)
        }
        Canvas(Modifier.fillMaxWidth().height(105.dp).padding(top = 8.dp)) {
            val count = 48
            val gap = 3.dp.toPx()
            val barWidth = (size.width - gap * (count - 1)) / count
            for (i in 0 until count) {
                val wave = (0.18f + ((i * 37 % 19) / 24f)) * (if (i % 7 == 0) pulse else 1f)
                val h = size.height * wave.coerceIn(0.12f, 0.95f)
                val x = i * (barWidth + gap)
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(Color(0xFFFFC34D), Green, Cyan, Blue)),
                    topLeft = Offset(x, size.height - h),
                    size = androidx.compose.ui.geometry.Size(barWidth, h),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx())
                )
            }
        }
        Text("Visual meter preview • DSP signal path becomes active after START", color = Muted, fontSize = 8.sp)
    }
}

@Composable
private fun Fader(
    label: String,
    value: Float,
    unit: String,
    min: Float,
    max: Float,
    modifier: Modifier = Modifier,
    onValue: (Float) -> Unit
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color(0xFFB9D6E8), fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Box(
            modifier = Modifier.weight(1f).fillMaxWidth()
                .padding(vertical = 6.dp)
                .pointerInput(min, max) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val fraction = (1f - offset.y / size.height).coerceIn(0f, 1f)
                            onValue(min + fraction * (max - min))
                        },
                        onDrag = { change, _ ->
                            val fraction = (1f - change.position.y / size.height).coerceIn(0f, 1f)
                            onValue(min + fraction * (max - min))
                            change.consume()
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val centerX = size.width / 2
                drawRoundRect(Color(0xFF253B50), Offset(centerX - 3.dp.toPx(), 0f), androidx.compose.ui.geometry.Size(6.dp.toPx(), size.height), cornerRadius = androidx.compose.ui.geometry.CornerRadius(5.dp.toPx()))
                val fraction = ((value - min) / (max - min)).coerceIn(0f, 1f)
                val y = size.height * (1f - fraction)
                drawRoundRect(Brush.verticalGradient(listOf(Cyan, Blue)), Offset(centerX - 7.dp.toPx(), y - 9.dp.toPx()), androidx.compose.ui.geometry.Size(14.dp.toPx(), 18.dp.toPx()), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                drawCircle(Color.White, radius = 2.dp.toPx(), center = Offset(centerX, y))
            }
        }
        Text(formatValue(value, unit), color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(unit.uppercase(), color = Muted, fontSize = 7.sp)
    }
}

private fun formatValue(value: Float, unit: String): String {
    val digits = if (unit == "x" || unit == "dB") 1 else 0
    return "%.${digits}f".format(java.util.Locale.US, value)
}
