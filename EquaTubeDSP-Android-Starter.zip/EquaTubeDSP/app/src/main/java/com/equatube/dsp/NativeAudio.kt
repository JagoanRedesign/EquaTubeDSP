package com.equatube.dsp

internal object NativeAudio {
    init {
        System.loadLibrary("equatube_dsp")
    }

    external fun nativeStart(): Boolean
    external fun nativeStop()
    external fun nativeSetDynamics(
        ratio: Float,
        knee: Float,
        attack: Float,
        release: Float,
        gain: Float
    )
    external fun nativeSetBand(band: Int, enabled: Boolean)
}
