package com.example.equatubedsp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    external fun nativeStartEngine(): Boolean
    external fun nativeStopEngine()
    external fun nativeSetParameters(
        ratio: Float, knee: Float, attack: Float, release: Float, gain: Float
    )
    external fun nativeSetFilterMask(mask: Int)

    companion object {
        init {
            System.loadLibrary("equatube_dsp")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EquaTubeApp(
                onStart = { nativeStartEngine() },
                onStop = { nativeStopEngine() },
                onParameters = { ratio, knee, attack, release, gain ->
                    nativeSetParameters(ratio, knee, attack, release, gain)
                },
                onFilterMask = { nativeSetFilterMask(it) }
            )
        }
    }

    override fun onDestroy() {
        nativeStopEngine()
        super.onDestroy()
    }
}

private val Bg = Color(0xFF10151D)
private val Panel = Color(0xFF1A2330)
private val Accent = Color(0xFF43D9B5)
private val Muted = Color(0xFF8C9AAA)
private val White = Color(0xFFEAF1F7)

@Composable
private fun EquaTubeApp(
    onStart: () -> Boolean,
    onStop: () -> Unit,
    onParameters: (Float, Float, Float, Float, Float) -> Unit,
    onFilterMask: (Int) -> Unit
) {
    var running by remember { mutableStateOf(false) }
    var engineMessage by remember { mutableStateOf("ENGINE STOPPED") }

    var ratio by remember { mutableStateOf(4f) }
    var knee by remember { mutableStateOf(6f) }
    var attack by remember { mutableStateOf(10f) }
    var release by remember { mutableStateOf(100f) }
    var gain by remember { mutableStateOf(1f) }
    var filterMask by remember { mutableIntStateOf(0) }

    fun pushParams() = onParameters(ratio, knee, attack, release, gain)

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            running = onStart()
            engineMessage = if (running) "INPUT → DSP → OUTPUT" else "AUDIO DEVICE OPEN FAILED"
        } else {
            engineMessage = "MICROPHONE PERMISSION REQUIRED"
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("EQUATUBE", color = White, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Text("DSP  •  LIVE AUDIO PROCESSOR", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Button(
                        onClick = {
                            if (running) {
                                onStop()
                                running = false
                                engineMessage = "ENGINE STOPPED"
                            } else {
                                // Runtime permission is checked before opening the input stream.
                                // Permission launcher is declared below and invoked from this button.
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (running) Color(0xFF633C48) else Accent,
                            contentColor = if (running) White else Bg
                        )
                    ) {
                        Text(if (running) "STOP" else "START", fontWeight = FontWeight.Bold)
                    }
                }

                SpectrumPanel()
                Text(engineMessage, color = if (running) Accent else Muted, fontSize = 10.sp, letterSpacing = 1.sp)

                Text("BAND FILTER", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                val filterNames = listOf("SUB", "LOW", "MID", "HIGH", "AIR")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    filterNames.forEachIndexed { index, name ->
                        val active = (filterMask and (1 shl index)) != 0
                        Button(
                            modifier = Modifier.weight(1f),
                            onClick = {
                                filterMask = if (active) filterMask and (1 shl index).inv()
                                else filterMask or (1 shl index)
                                onFilterMask(filterMask)
                            },
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 10.dp, horizontal = 2.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (active) Accent else Panel,
                                contentColor = if (active) Bg else Muted
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(name, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Text("DYNAMICS & OUTPUT", color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.Bottom
                ) {
                    VerticalFader("RATIO", ratio, 1f, 20f, "%.1f".format(ratio)) {
                        ratio = it
                        pushParams()
                    }
                    VerticalFader("KNEE", knee, 0f, 12f, "%.1f dB".format(knee)) {
                        knee = it
                        pushParams()
                    }
                    VerticalFader("ATTACK", attack, 1f, 100f, "%.0f ms".format(attack)) {
                        attack = it
                        pushParams()
                    }
                    VerticalFader("RELEASE", release, 10f, 500f, "%.0f ms".format(release)) {
                        release = it
                        pushParams()
                    }
                    VerticalFader("GAIN", gain, 0f, 2.5f, "%.2f×".format(gain)) {
                        gain = it
                        pushParams()
                    }
                }

                Text(
                    "FLOAT PCM  •  OBOE  •  LOW-LATENCY REQUEST",
                    color = Muted, fontSize = 9.sp, letterSpacing = 1.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun SpectrumPanel() {
    Column(
        modifier = Modifier.fillMaxWidth()
            .height(132.dp)
            .background(Panel, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("SPECTRUM MONITOR", color = White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("INPUT", color = Accent, fontSize = 10.sp)
        }
        Spacer(Modifier.height(8.dp))
        Canvas(modifier = Modifier.fillMaxSize()) {
            val count = 42
            val gap = 4.dp.toPx()
            val barWidth = (size.width - gap * (count - 1)) / count
            val heights = listOf(
                .22f,.28f,.34f,.25f,.42f,.56f,.44f,.31f,.38f,.62f,.73f,.51f,
                .39f,.47f,.68f,.82f,.59f,.42f,.33f,.49f,.64f,.76f,.55f,.38f,
                .29f,.45f,.61f,.71f,.48f,.35f,.27f,.39f,.52f,.43f,.31f,.22f,
                .35f,.47f,.32f,.25f,.19f,.28f
            )
            heights.forEachIndexed { i, h ->
                val x = i * (barWidth + gap)
                val barHeight = size.height * h
                drawRoundRect(
                    color = if (i in 10..29) Accent else Color(0xFF3B8290),
                    topLeft = Offset(x, size.height - barHeight),
                    size = Size(barWidth, barHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx())
                )
            }
        }
    }
}

@Composable
private fun VerticalFader(
    label: String,
    value: Float,
    min: Float,
    max: Float,
    valueText: String,
    onValueChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier.width(58.dp).fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom
    ) {
        Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Canvas(
            modifier = Modifier.weight(1f).fillMaxWidth()
                .pointerInput(min, max) {
                    detectTapGestures { offset ->
                        val fraction = (1f - offset.y / size.height).coerceIn(0f, 1f)
                        onValueChange(min + fraction * (max - min))
                    }
                }
                .pointerInput(min, max) {
                    detectDragGestures { change, _ ->
                        val fraction = (1f - change.position.y / size.height).coerceIn(0f, 1f)
                        onValueChange(min + fraction * (max - min))
                    }
                }
        ) {
            val centerX = size.width / 2f
            val top = 8.dp.toPx()
            val bottom = size.height - 8.dp.toPx()
            val trackTop = top
            val trackBottom = bottom
            val fraction = ((value - min) / (max - min)).coerceIn(0f, 1f)
            val thumbY = trackBottom - fraction * (trackBottom - trackTop)

            drawLine(
                color = Color(0xFF3A4655),
                start = Offset(centerX, trackTop),
                end = Offset(centerX, trackBottom),
                strokeWidth = 5.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = Accent,
                start = Offset(centerX, thumbY),
                end = Offset(centerX, trackBottom),
                strokeWidth = 5.dp.toPx(),
                cap = StrokeCap.Round
            )
            for (tick in 0..10) {
                val y = trackTop + (trackBottom - trackTop) * tick / 10f
                drawLine(
                    color = Muted.copy(alpha = 0.55f),
                    start = Offset(centerX + 9.dp.toPx(), y),
                    end = Offset(centerX + 15.dp.toPx(), y),
                    strokeWidth = 1.dp.toPx()
                )
            }
            drawRoundRect(
                color = Color(0xFFE7EEF4),
                topLeft = Offset(centerX - 15.dp.toPx(), thumbY - 7.dp.toPx()),
                size = Size(30.dp.toPx(), 14.dp.toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx())
            )
            drawRoundRect(
                color = Accent,
                topLeft = Offset(centerX - 2.dp.toPx(), thumbY - 5.dp.toPx()),
                size = Size(4.dp.toPx(), 10.dp.toPx()),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(valueText, color = White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}
